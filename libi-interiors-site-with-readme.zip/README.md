# Libi Interiors 🌿

A modern, elegant website for **Libi Interiors** — a creative interior design studio specializing in residential, commercial, renovation, and 2D/3D interior visualization services.

## ✨ Live Site

👉 [View on GitHub Pages](https://your-username.github.io/libi-interiors/)  
*(replace `your-username` with your actual GitHub username after deploying)*

---

## 📂 Project Structure

```bash
libi-interiors/
├── index.html       # Main website file
```

---

## 🛠 Services Featured

- ✅ Residential Interior Design
- ✅ Commercial Interior Design
- ✅ Renovations & Space Planning
- ✅ 2D & 3D Rendered Designs
- ✅ Contact Form
- ✅ Testimonials & Portfolio

---

## 🚀 How to Use

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/libi-interiors.git
   cd libi-interiors
   ```

2. Open `index.html` in your browser or host it on GitHub Pages.

---

## 🖼 Screenshots

![Preview](https://source.unsplash.com/1600x600/?interior-design)

---

## 📢 Credits

- Built using pure **HTML5 + CSS3**
- Fonts by [Google Fonts](https://fonts.google.com/)
- Images by [Unsplash](https://unsplash.com/)

---

## 📬 Contact

For collaboration or custom interior projects, visit the [Contact Form](#contact) on the site.

---

&copy; 2025 Libi Interiors. All rights reserved.
